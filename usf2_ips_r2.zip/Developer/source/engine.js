/* Offline ZIP + standard IPS engine. No dependencies or network access. */
function createUltraEngine() {
  'use strict';
  const text = new TextDecoder(), encode = new TextEncoder();
  const crcTable = Uint32Array.from({ length: 256 }, (_, index) => {
    let value = index;
    for (let bit = 0; bit < 8; bit++) value = (value & 1) ? 0xedb88320 ^ (value >>> 1) : value >>> 1;
    return value >>> 0;
  });
  function crc32(bytes) {
    let value = 0xffffffff;
    for (const byte of bytes) value = crcTable[(value ^ byte) & 255] ^ (value >>> 8);
    return (value ^ 0xffffffff) >>> 0;
  }
  async function sha(bytes) {
    const result = await crypto.subtle.digest('SHA-256', bytes);
    return Array.from(new Uint8Array(result), byte => byte.toString(16).padStart(2, '0')).join('');
  }
  function combine(parts) {
    const result = new Uint8Array(parts.reduce((sum, part) => sum + part.length, 0));
    let cursor = 0;
    for (const part of parts) { result.set(part, cursor); cursor += part.length; }
    return result;
  }
  async function transform(bytes, format, compress, maximum = 134217728) {
    const stream = new Blob([bytes]).stream().pipeThrough(compress ? new CompressionStream(format) : new DecompressionStream(format));
    const reader = stream.getReader(), chunks = [];
    let total = 0;
    try {
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        total += value.length;
        if (total > maximum) throw new Error('The ZIP or patch contains an oversized entry.');
        chunks.push(value);
      }
    } catch (error) { await reader.cancel().catch(() => {}); throw error; }
    return combine(chunks);
  }
  function zipIndex(bytes) {
    if (bytes.length < 22 || bytes.length > 134217728) throw new Error('Choose the supplied Super Turbo ZIP.');
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    let end = -1;
    for (let offset = bytes.length - 22; offset >= Math.max(0, bytes.length - 65557); offset--) {
      if (view.getUint32(offset, true) === 0x06054b50 && offset + 22 + view.getUint16(offset + 20, true) === bytes.length) { end = offset; break; }
    }
    if (end < 0 || view.getUint16(end + 4, true) || view.getUint16(end + 6, true)) throw new Error('Invalid or unsupported ZIP archive.');
    const count = view.getUint16(end + 10, true), centralSize = view.getUint32(end + 12, true), centralStart = view.getUint32(end + 16, true);
    if (count > 4096 || count !== view.getUint16(end + 8, true) || centralStart + centralSize !== end) throw new Error('Invalid or ZIP64 archive. Use the supplied Super Turbo set.');
    const entries = [];
    let cursor = centralStart;
    for (let index = 0; index < count; index++) {
      if (cursor + 46 > end || view.getUint32(cursor, true) !== 0x02014b50) throw new Error('Damaged ZIP directory.');
      const flags = view.getUint16(cursor + 8, true), method = view.getUint16(cursor + 10, true);
      const crc = view.getUint32(cursor + 16, true), compressed = view.getUint32(cursor + 20, true), size = view.getUint32(cursor + 24, true);
      const nameLength = view.getUint16(cursor + 28, true), extra = view.getUint16(cursor + 30, true), comment = view.getUint16(cursor + 32, true);
      const local = view.getUint32(cursor + 42, true), next = cursor + 46 + nameLength + extra + comment;
      if (next > end || local + 30 > centralStart) throw new Error('Invalid ZIP offsets.');
      const fullName = text.decode(bytes.subarray(cursor + 46, cursor + 46 + nameLength));
      if (!fullName.endsWith('/')) entries.push({ name: fullName.replace(/\\/g, '/').split('/').pop().toLowerCase(), flags, method, crc, compressed, size, local });
      cursor = next;
    }
    if (cursor !== end) throw new Error('Unexpected ZIP directory data.');
    return { entries, view, centralStart };
  }
  async function readSource(bytes, manifest, progress) {
    const { entries, view, centralStart } = zipIndex(bytes), required = new Map(manifest.source_members.map(entry => [entry.name.toLowerCase(), entry]));
    const chosen = new Map(), result = new Map();
    for (const entry of entries) {
      if (!required.has(entry.name)) continue;
      if (chosen.has(entry.name)) throw new Error('Duplicate source ROM: ' + entry.name);
      chosen.set(entry.name, entry);
    }
    for (const [name] of required) if (!chosen.has(name)) throw new Error('Missing source ROM: ' + name + '. Choose the complete supplied ssf2t.zip.');
    let index = 0;
    for (const [name, expected] of required) {
      const entry = chosen.get(name);
      if (entry.size !== expected.size || entry.flags & 1 || ![0, 8].includes(entry.method)) throw new Error('Wrong or unsupported source ROM: ' + name);
      if (view.getUint32(entry.local, true) !== 0x04034b50) throw new Error('Damaged ZIP entry: ' + name);
      const start = entry.local + 30 + view.getUint16(entry.local + 26, true) + view.getUint16(entry.local + 28, true);
      if (start + entry.compressed > centralStart) throw new Error('Damaged ZIP payload: ' + name);
      let data = bytes.subarray(start, start + entry.compressed);
      if (entry.method === 8) data = await transform(data, 'deflate-raw', false, expected.size);
      if (data.length !== expected.size || crc32(data) !== entry.crc || await sha(data) !== expected.sha256) throw new Error('Wrong Super Turbo revision or damaged ROM: ' + name);
      result.set(name, data);
      progress(5 + ++index / required.size * 25, 'Checking source ROMs', name);
    }
    return result;
  }
  function applyIPS(seed, patch) {
    if (text.decode(patch.subarray(0, 5)) !== 'PATCH') throw new Error('Invalid IPS header.');
    const output = seed.slice();
    let cursor = 5;
    function number(length) {
      if (cursor + length > patch.length) throw new Error('Truncated IPS patch.');
      let value = 0;
      for (let i = 0; i < length; i++) value = value * 256 + patch[cursor++];
      return value;
    }
    for (;;) {
      const offset = number(3);
      if (offset === 0x454f46) {
        if (cursor !== patch.length && (patch.length - cursor !== 3 || number(3) !== output.length)) throw new Error('Unexpected IPS output size.');
        return output;
      }
      let length = number(2), fill = null;
      if (!length) { length = number(2); fill = number(1); if (!length) throw new Error('Empty IPS RLE record.'); }
      if (offset + length > output.length) throw new Error('IPS record exceeds the ROM size.');
      if (fill !== null) output.fill(fill, offset, offset + length);
      else {
        if (cursor + length > patch.length) throw new Error('Truncated IPS payload.');
        output.set(patch.subarray(cursor, cursor + length), offset);
        cursor += length;
      }
    }
  }
  function seedFor(entry, source) {
    const seed = new Uint8Array(entry.size).fill(entry.seed_fill);
    for (const part of entry.seed_parts) {
      const data = source.get(part.source.toLowerCase());
      if (!data || part.source_offset < 0 || part.target_offset < 0 || part.source_offset + part.length > data.length || part.target_offset + part.length > seed.length) throw new Error('Invalid ROM layout: ' + entry.name);
      seed.set(data.subarray(part.source_offset, part.source_offset + part.length), part.target_offset);
    }
    return seed;
  }
  function base64(value) {
    const string = atob(value), output = new Uint8Array(string.length);
    for (let i = 0; i < string.length; i++) output[i] = string.charCodeAt(i);
    return output;
  }
  function writeZIP(entries, timestamp) {
    const local = [], directory = [];
    const date = ((timestamp[0] - 1980) << 9) | (timestamp[1] << 5) | timestamp[2];
    let offset = 0;
    for (const entry of entries) {
      const name = encode.encode(entry.name), header = new Uint8Array(30 + name.length), v = new DataView(header.buffer);
      v.setUint32(0, 0x04034b50, true); v.setUint16(4, 20, true); v.setUint16(8, 8, true); v.setUint16(12, date, true);
      v.setUint32(14, entry.crc, true); v.setUint32(18, entry.data.length, true); v.setUint32(22, entry.size, true); v.setUint16(26, name.length, true); header.set(name, 30);
      local.push(header, entry.data);
      const central = new Uint8Array(46 + name.length), c = new DataView(central.buffer);
      c.setUint32(0, 0x02014b50, true); c.setUint16(4, 0x0314, true); c.setUint16(6, 20, true); c.setUint16(10, 8, true); c.setUint16(14, date, true);
      c.setUint32(16, entry.crc, true); c.setUint32(20, entry.data.length, true); c.setUint32(24, entry.size, true); c.setUint16(28, name.length, true);
      c.setUint32(38, 0x81a40000, true); c.setUint32(42, offset, true); central.set(name, 46); directory.push(central);
      offset += header.length + entry.data.length;
    }
    const centralSize = directory.reduce((sum, part) => sum + part.length, 0), footer = new Uint8Array(22), f = new DataView(footer.buffer);
    f.setUint32(0, 0x06054b50, true); f.setUint16(8, entries.length, true); f.setUint16(10, entries.length, true); f.setUint32(12, centralSize, true); f.setUint32(16, offset, true);
    return combine([...local, ...directory, footer]);
  }
  async function convert(bytes, kit, progress = () => {}) {
    if (!globalThis.crypto?.subtle || typeof CompressionStream === 'undefined' || typeof DecompressionStream === 'undefined') throw new Error('Open START_HERE.html in a current version of Microsoft Edge or Chrome.');
    const manifest = kit.manifest;
    progress(1, 'Reading Super Turbo ZIP', 'Your source file stays untouched.');
    const source = await readSource(bytes, manifest, progress), entries = [];
    let index = 0;
    for (const entry of manifest.output_members) {
      let data = seedFor(entry, source);
      if (await sha(data) !== entry.seed_sha256) throw new Error('Base ROM checksum mismatch: ' + entry.name);
      if (entry.patch) {
        const packed = kit.patches[entry.patch];
        if (!packed) throw new Error('Missing patch data. Extract the complete kit again.');
        const patch = await transform(base64(packed), 'gzip', false, entry.patch_bytes);
        if (await sha(patch) !== entry.patch_sha256) throw new Error('Damaged IPS patch: ' + entry.name);
        data = applyIPS(data, patch);
      }
      if (data.length !== entry.size || await sha(data) !== entry.sha256 || crc32(data) !== parseInt(entry.crc32, 16)) throw new Error('Ultra ROM checksum mismatch: ' + entry.name);
      const compressed = await transform(data, 'deflate-raw', true);
      entries.push({ name: entry.name, size: entry.size, crc: parseInt(entry.crc32, 16), data: compressed });
      progress(30 + ++index / manifest.output_members.length * 65, 'Building Ultra Street Fighter II', 'Verified ' + entry.name);
    }
    progress(97, 'Finishing hsf2.zip', 'All ' + entries.length + ' Ultra ROMs match the reference build.');
    const output = writeZIP(entries, manifest.zip_timestamp), outputSHA = await sha(output);
    progress(100, 'Ready', 'All ' + entries.length + ' ROM checksums verified.');
    return { output, sha256: outputSHA, referenceArchiveMatch: outputSHA === manifest.reference_archive_sha256, verifiedMembers: entries.length };
  }
  return { convert, applyIPS, readSource, writeZIP, crc32, sha };
}
if (typeof module !== 'undefined' && module.exports) module.exports = { createUltraEngine };
if (typeof globalThis !== 'undefined') globalThis.createUltraEngine = createUltraEngine;
