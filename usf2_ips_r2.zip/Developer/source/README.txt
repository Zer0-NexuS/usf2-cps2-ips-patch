UltraSF2 - Dev (CPS2, Native)
Super Turbo -> Ultra SF2 IPS conversion kit

DRAG AND DROP
1. Extract this entire kit to a folder.
2. Open START_HERE.html in Microsoft Edge or Google Chrome.
3. Drop your supplied ssf2t.zip into the patcher.
4. Click Save hsf2.zip and put that file in your MAME ROM folder.

No installation, Python, server, or Internet connection is needed by the
front end. Keep START_HERE.html and the assets folder together. The source
ZIP is read locally and is never overwritten or uploaded.

SUPPORTED INPUT AND OUTPUT
Input: the supplied World Super Street Fighter II Turbo set, including
sfxe.03c and sfxe.04a. A repacked ZIP with those same ROM bytes also works.
Other revisions or incomplete sets are rejected with the missing/bad ROM name.
Source archive SHA-256:
9576e82b9cb8eb430b8758f533c503faeebd47c329cec5de00e0e3f6f898c601

Output: the current Ultra hsf2.zip build, revision 7 (native ROM audit),
including all accepted artwork, audio, coin-in and title-outro fixes.
All 17 output ROM names, lengths, CRC32s and SHA-256 hashes must match
manifest.json before the download becomes available.
Reference hsf2.zip SHA-256:
3c968b8da80fdb15e0f8e31ae1dd9d1a39fd884e30daa753bbbe2d03922165db

Browsers may use different ZIP compression, so the ZIP container's checksum
can differ while all 17 ROM files are byte-identical. The Python converter
also verifies the ROM contents and uses the reference ZIP layout.
If your browser adds a suffix to a duplicate download, use the name hsf2.zip
when installing the result in MAME.

WHAT IS IN THE KIT
START_HERE.html         Drag-and-drop front end.
assets/                Offline engine and embedded compressed IPS data.
patches/               16 ordinary IPS patches for the changed output ROMs.
manifest.json          Source hashes, seed layout, patch hashes, output hashes.
convert.py             Optional Python 3 command-line converter.
Developer/             Patch generator, front-end source and verification.

The sets have different ROM layouts: graphics and sample ROMs are combined
and expanded, program names change, and an extra program ROM is created.
The front end builds the documented base image for each output, applies its
IPS patch, copies the unchanged dl-1425.bin, and writes the complete set.
Each IPS patch uses the standard PATCH/EOF format, 24-bit offsets, 16-bit
literal lengths and optional RLE records. Every individual ROM fits IPS.

OPTIONAL PYTHON COMMAND LINE
Requires Python 3.9 or later; only the standard library is used.
From the extracted kit folder:
  python convert.py "C:\path\ssf2t.zip" -o "C:\path\Ultra\hsf2.zip"
The converter refuses to overwrite an existing output.

USING OTHER IPS PATCHERS
These IPS files apply to the assembled base images, not to the ZIP file.
Export the base images while converting:
  python convert.py ssf2t.zip -o Ultra\hsf2.zip --export-seeds IPS_Seeds
For each changed ROM, apply patches/<ROM name>.ips to IPS_Seeds/<ROM name>.
Retain the manifest's output size and filename, copy dl-1425.bin, then ZIP
all 17 resulting ROMs at the archive root. The bundled front end does this
automatically, including source and output checksum validation.

REBUILDING THE PATCH KIT
Developer/source/build_kit.py requires Python, NumPy and both original ZIPs.
The generator is pinned to the current Ultra reference hash above.
  python Developer/source/build_kit.py --source ssf2t.zip --target hsf2.zip --out rebuilt_kit

FORMAT AND PLATFORM REFERENCES
https://github.com/bbbradsmith/ipstool
https://developer.chrome.com/blog/compression-streams-api/
https://developer.mozilla.org/en-US/docs/Web/API/CompressionStream/CompressionStream
