#!/usr/bin/env python3
"""Offline Super Turbo -> Ultra SF2 converter; Python standard library only."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import struct
import tempfile
import zipfile


class ConversionError(ValueError):
    pass


def digest(data):
    return hashlib.sha256(data).hexdigest()


def apply_ips(seed, patch):
    """Apply ordinary IPS records to the manifest-sized seed, strictly."""
    if not patch.startswith(b'PATCH'):
        raise ConversionError('Invalid IPS header')
    result = bytearray(seed)
    cursor = 5
    while True:
        if cursor + 3 > len(patch):
            raise ConversionError('Truncated IPS record')
        field = patch[cursor:cursor + 3]
        cursor += 3
        if field == b'EOF':
            tail = patch[cursor:]
            if tail and (len(tail) != 3 or int.from_bytes(tail, 'big') != len(result)):
                raise ConversionError('Unexpected IPS output size')
            return bytes(result)
        if cursor + 2 > len(patch):
            raise ConversionError('Truncated IPS length')
        offset = int.from_bytes(field, 'big')
        length = int.from_bytes(patch[cursor:cursor + 2], 'big')
        cursor += 2
        if length:
            if cursor + length > len(patch):
                raise ConversionError('Truncated IPS payload')
            value = patch[cursor:cursor + length]
            cursor += length
        else:
            if cursor + 3 > len(patch):
                raise ConversionError('Truncated IPS RLE')
            length = int.from_bytes(patch[cursor:cursor + 2], 'big')
            if not length:
                raise ConversionError('Empty IPS RLE record')
            value = patch[cursor + 2:cursor + 3] * length
            cursor += 3
        if offset + length > len(result):
            raise ConversionError('IPS record exceeds the output ROM')
        result[offset:offset + length] = value


def read_source(path, manifest):
    required = {entry['name'].lower(): entry for entry in manifest['source_members']}
    found = {}
    with zipfile.ZipFile(path) as archive:
        for entry in archive.infolist():
            if entry.is_dir():
                continue
            name = entry.filename.replace('\\', '/').rsplit('/', 1)[-1].lower()
            if name not in required:
                continue
            if name in found:
                raise ConversionError('Duplicate source ROM: ' + name)
            expected = required[name]
            if entry.file_size != expected['size'] or entry.flag_bits & 1:
                raise ConversionError('Wrong source ROM: ' + name)
            data = archive.read(entry)
            if digest(data) != expected['sha256']:
                raise ConversionError('Wrong source revision or damaged ROM: ' + name)
            found[name] = data
    missing = sorted(set(required) - set(found))
    if missing:
        raise ConversionError('Missing source ROMs: ' + ', '.join(missing))
    return found


def make_seed(entry, source):
    seed = bytearray([entry['seed_fill']]) * entry['size']
    for part in entry['seed_parts']:
        data = source[part['source'].lower()]
        begin, length, destination = part['source_offset'], part['length'], part['target_offset']
        if begin < 0 or destination < 0 or begin + length > len(data) or destination + length > len(seed):
            raise ConversionError('Invalid seed layout: ' + entry['name'])
        seed[destination:destination + length] = data[begin:begin + length]
    if digest(seed) != entry['seed_sha256']:
        raise ConversionError('Seed checksum mismatch: ' + entry['name'])
    return bytes(seed)


def convert(input_zip, output_zip, kit_root, export_seeds=None):
    kit_root, input_zip, output_zip = Path(kit_root), Path(input_zip), Path(output_zip)
    manifest = json.loads((kit_root / 'manifest.json').read_text(encoding='utf-8'))
    if input_zip.resolve() == output_zip.resolve():
        raise ConversionError('Choose a different output file; the source is preserved')
    if output_zip.exists():
        raise ConversionError('Output already exists: ' + str(output_zip))
    source = read_source(input_zip, manifest)
    output = []
    for entry in manifest['output_members']:
        seed = make_seed(entry, source)
        if export_seeds:
            root = Path(export_seeds)
            root.mkdir(parents=True, exist_ok=True)
            destination = root / entry['name']
            if destination.exists():
                raise ConversionError('Seed already exists: ' + str(destination))
            destination.write_bytes(seed)
        if entry['patch']:
            patch = (kit_root / entry['patch']).read_bytes()
            if digest(patch) != entry['patch_sha256']:
                raise ConversionError('Damaged patch: ' + entry['patch'])
            data = apply_ips(seed, patch)
        else:
            data = seed
        if len(data) != entry['size'] or digest(data) != entry['sha256']:
            raise ConversionError('Output checksum mismatch: ' + entry['name'])
        output.append((entry, data))
        print('Verified ' + entry['name'], flush=True)
    output_zip.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=output_zip.parent, prefix='UltraSF2_', suffix='.tmp', delete=False) as handle:
            temporary = Path(handle.name)
        with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for entry, data in output:
                info = zipfile.ZipInfo(entry['name'], tuple(manifest['zip_timestamp']))
                info.create_system = 3
                info.external_attr = 0o100644 << 16
                info.compress_type = zipfile.ZIP_DEFLATED
                archive.writestr(info, data, compresslevel=6)
        with zipfile.ZipFile(temporary) as archive:
            if archive.testzip() is not None:
                raise ConversionError('Output ZIP verification failed')
            for entry in manifest['output_members']:
                if digest(archive.read(entry['name'])) != entry['sha256']:
                    raise ConversionError('Output ZIP member verification failed')
        # A hard link creates the destination only if it is still absent.
        os.link(temporary, output_zip)
        return output_zip
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path, help='The supplied ssf2t.zip revision')
    parser.add_argument('-o', '--output', type=Path)
    parser.add_argument('--export-seeds', type=Path, help='Optional base images for external IPS patchers')
    args = parser.parse_args()
    output = args.output or args.source.resolve().parent / 'UltraSF2_Output' / 'hsf2.zip'
    try:
        result = convert(args.source, output, Path(__file__).resolve().parent, args.export_seeds)
    except (ConversionError, OSError, zipfile.BadZipFile) as error:
        parser.exit(1, 'Conversion failed: ' + str(error) + '\n')
    print('Created ' + str(result))


if __name__ == '__main__':
    main()
