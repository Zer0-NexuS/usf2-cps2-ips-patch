#!/usr/bin/env python3
"""Generate standard per-ROM IPS patches from the two user-provided sets."""
from pathlib import Path
import base64
import argparse
import gzip
import hashlib
import json
import shutil
import struct
import sys
import zipfile
import numpy as np
from convert import apply_ips, make_seed

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'ips_kit/build/UltraSF2_IPS_Kit'
TARGET_SHA = '3c968b8da80fdb15e0f8e31ae1dd9d1a39fd884e30daa753bbbe2d03922165db'
sha = lambda data: hashlib.sha256(data).hexdigest()


def create_ips(seed, target):
    assert len(seed) == len(target) and len(target) <= 0x1000000
    records = bytearray(b'PATCH')
    special = int.from_bytes(b'EOF', 'big')

    def literal(start, end):
        while start < end:
            if start == special:
                start -= 1
            stop = min(end, start + 65535)
            records.extend(start.to_bytes(3, 'big'))
            records.extend((stop - start).to_bytes(2, 'big'))
            records.extend(target[start:stop])
            start = stop

    def repeated(start, end):
        while start < end:
            if start == special:
                literal(start - 1, start + 1)
                start += 1
                continue
            stop = min(end, start + 65535)
            records.extend(start.to_bytes(3, 'big') + b'\0\0')
            records.extend((stop - start).to_bytes(2, 'big'))
            records.append(target[start])
            start = stop

    changed = np.flatnonzero(np.frombuffer(seed, dtype='u1') != np.frombuffer(target, dtype='u1'))
    if len(changed):
        # Including <=5 unchanged bytes costs no more than another IPS header.
        breaks = np.flatnonzero(np.diff(changed) > 6)
        starts = np.r_[changed[0], changed[breaks + 1]]
        ends = np.r_[changed[breaks] + 1, changed[-1] + 1]
        for begin, end in zip(starts, ends):
            begin, end = int(begin), int(end)
            data = np.frombuffer(target, dtype='u1', count=end - begin, offset=begin)
            boundaries = np.r_[0, np.flatnonzero(data[1:] != data[:-1]) + 1, len(data)]
            long_runs = np.flatnonzero(np.diff(boundaries) >= 16)
            cursor = begin
            for index in long_runs:
                lo, hi = begin + int(boundaries[index]), begin + int(boundaries[index + 1])
                literal(cursor, lo)
                repeated(lo, hi)
                cursor = hi
            literal(cursor, end)
    records.extend(b'EOF')
    result = bytes(records)
    assert apply_ips(seed, result) == target
    return result


def build(source_path, target_path, output):
    global OUT
    OUT = Path(output)
    assert sha(target_path.read_bytes()) == TARGET_SHA
    source_archive, target_archive = zipfile.ZipFile(source_path), zipfile.ZipFile(target_path)
    assert source_archive.testzip() is None and target_archive.testzip() is None
    source = {name: source_archive.read(name) for name in source_archive.namelist()}
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / 'patches').mkdir(exist_ok=True)
    (OUT / 'assets').mkdir(exist_ok=True)
    manifest = dict(format='UltraSF2 IPS kit', version=1, source_archive='ssf2t.zip',
                    source_archive_sha256=sha(source_path.read_bytes()), target_archive='hsf2.zip',
                    reference_archive_sha256=TARGET_SHA, target_release='Native ROM audit, revision 7',
                    zip_timestamp=[2026,10,20,0,0,0], source_members=[], output_members=[])
    for name, data in source.items():
        manifest['source_members'].append(dict(name=name, size=len(data), sha256=sha(data)))
    simple = {'dl-1425.bin':'dl-1425.bin','hs2.01':'sfx.01','hs2.02':'sfx.02',
              'hs2u.03':'sfxe.03c','hs2u.04':'sfxe.04a','hs2.05':'sfxe.05',
              'hs2.06':'sfxe.06a','hs2.07':'sfxe.07','hs2.08':'sfxe.08','hs2.09':'sfx.09','hsf2.key':'ssf2t.key'}
    combined = {'hs2.11m':['sfx.11m','sfx.12m'],
                'hs2.13m':['sfx.13m','sfx.14m','sfx.21m'],
                'hs2.15m':['sfx.15m','sfx.16m','sfx.23m'],
                'hs2.17m':['sfx.17m','sfx.18m','sfx.25m'],
                'hs2.19m':['sfx.19m','sfx.20m','sfx.27m']}
    payload = {}
    for name in target_archive.namelist():
        target = target_archive.read(name)
        entry = dict(name=name, size=len(target), sha256=sha(target),
                     crc32=f'{target_archive.getinfo(name).CRC:08x}',
                     seed_fill=255 if name in combined and name!='hs2.11m' else 0, seed_parts=[])
        cursor = 0
        for base in [simple[name]] if name in simple else combined.get(name, []):
            length = len(source[base])
            entry['seed_parts'].append(dict(source=base, source_offset=0, target_offset=cursor, length=length))
            cursor += length
        seed = bytearray([entry['seed_fill']]) * entry['size']
        for part in entry['seed_parts']:
            start, length = part['target_offset'], part['length']
            seed[start:start+length] = source[part['source']]
        entry['seed_sha256'] = sha(seed)
        assert make_seed(entry, source) == seed
        if seed == target:
            entry.update(patch=None, patch_sha256=None)
        else:
            patch = create_ips(seed, target)
            entry.update(patch='patches/'+name+'.ips', patch_sha256=sha(patch), patch_bytes=len(patch))
            (OUT / entry['patch']).write_bytes(patch)
            payload[entry['patch']] = base64.b64encode(gzip.compress(patch, mtime=0)).decode('ascii')
        manifest['output_members'].append(entry)
        print(name, entry.get('patch_bytes', 0), flush=True)
    (OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
    bundle = dict(manifest=manifest, patches=payload)
    (OUT / 'assets/patch-data.js').write_text('globalThis.UltraKit='+json.dumps(bundle,separators=(',',':'))+';\n')
    templates = Path(__file__).resolve().parent
    for name,destination in [('convert.py','convert.py'),('engine.js','assets/engine.js'),('app.js','assets/app.js'),('START_HERE.html','START_HERE.html')]:
        (OUT / destination).write_bytes((templates / name).read_bytes())
    print(json.dumps(dict(output=str(OUT), ips_files=len(payload), ips_bytes=sum(e.get('patch_bytes',0)for e in manifest['output_members']))))


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',type=Path,default=ROOT/'upload/ssf2t.zip')
    parser.add_argument('--target',type=Path,default=ROOT/'deliverables/hsf2.zip')
    parser.add_argument('--out',type=Path,default=OUT)
    options=parser.parse_args()
    build(options.source,options.target,options.out)
