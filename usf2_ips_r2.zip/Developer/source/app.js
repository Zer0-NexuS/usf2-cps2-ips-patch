'use strict';
(() => {
  const $ = id => document.getElementById(id);
  let worker = null, workerURL = null, downloadURL = null, busy = false;
  function message(title, detail, error = false) {
    $('status').textContent = title; $('detail').textContent = detail;
    $('statusCard').classList.toggle('error', error);
  }
  function cleanWorker() {
    if (worker) worker.terminate();
    if (workerURL) URL.revokeObjectURL(workerURL);
    worker = null; workerURL = null; busy = false;
    $('choose').disabled = false; $('dropzone').setAttribute('aria-busy', 'false');
  }
  async function start(file) {
    if (busy || !file) return;
    if (file.size > 134217728) { message('Choose the Super Turbo ZIP', 'This file is too large for the supplied set.', true); return; }
    if (!window.UltraKit || !window.createUltraEngine) { message('Kit files are missing', 'Extract the entire kit, then open START_HERE.html again.', true); return; }
    busy = true; $('choose').disabled = true; $('dropzone').setAttribute('aria-busy', 'true');
    $('download').hidden = true; $('result').hidden = true; $('progress').value = 0; $('progress').hidden = false;
    $('sourceName').textContent = file.name;
    if (downloadURL) URL.revokeObjectURL(downloadURL);
    message('Reading your ZIP', 'Processing locally. Your original file stays untouched.');
    try {
      const source = await file.arrayBuffer();
      const code = `const engine=(${createUltraEngine.toString()})();self.onmessage=async e=>{try{const r=await engine.convert(new Uint8Array(e.data.source),e.data.kit,(value,title,detail)=>self.postMessage({type:'progress',value,title,detail}));self.postMessage({type:'done',buffer:r.output.buffer,sha256:r.sha256,members:r.verifiedMembers,exact:r.referenceArchiveMatch},[r.output.buffer]);}catch(error){self.postMessage({type:'error',message:error.message});}};`;
      workerURL = URL.createObjectURL(new Blob([code], { type: 'text/javascript' }));
      worker = new Worker(workerURL);
      worker.onmessage = ({ data }) => {
        if (data.type === 'progress') { $('progress').value = data.value; message(data.title, data.detail); }
        if (data.type === 'error') { message('Conversion stopped', data.message, true); cleanWorker(); }
        if (data.type === 'done') {
          downloadURL = URL.createObjectURL(new Blob([data.buffer], { type: 'application/zip' }));
          $('download').href = downloadURL; $('download').download = 'hsf2.zip'; $('download').hidden = false;
          $('progress').value = 100;
          message('Your Ultra ROM is ready', `All ${data.members} ROMs verified against our Ultra build.`);
          $('resultHash').textContent = data.sha256; $('result').hidden = false;
          cleanWorker(); $('download').focus();
        }
      };
      worker.onerror = () => { message('Could not start the patcher', 'Open START_HERE.html in current Microsoft Edge or Chrome, after extracting the entire kit.', true); cleanWorker(); };
      worker.postMessage({ source, kit: UltraKit }, [source]);
    } catch (error) { message('Conversion stopped', error.message, true); cleanWorker(); }
  }
  $('choose').addEventListener('click', () => $('file').click());
  $('file').addEventListener('change', event => { start(event.target.files[0]); event.target.value = ''; });
  $('dropzone').addEventListener('keydown', event => { if (['Enter', ' '].includes(event.key)) { event.preventDefault(); if (!busy) $('file').click(); } });
  for (const event of ['dragenter', 'dragover']) $('dropzone').addEventListener(event, e => { e.preventDefault(); if (!busy) $('dropzone').classList.add('dragging'); });
  $('dropzone').addEventListener('dragleave', () => $('dropzone').classList.remove('dragging'));
  $('dropzone').addEventListener('drop', event => {
    event.preventDefault(); $('dropzone').classList.remove('dragging');
    if (event.dataTransfer.files.length !== 1) { if (!busy) message('Drop one ZIP file', 'Use the supplied ssf2t.zip.', true); return; }
    start(event.dataTransfer.files[0]);
  });
  window.addEventListener('dragover', event => event.preventDefault());
  window.addEventListener('drop', event => event.preventDefault());
})();
